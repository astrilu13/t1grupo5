﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace grupo5t1
{
    public class ListaVideojuegos
    {
        private Nodo primero;

        public ListaVideojuegos()
        {
            primero = null;
        }

        // AGREGAR AL FINAL
        public void Agregar(string n, string g, int a, int s, double p)
        {
            Nodo nuevo = new Nodo(n, g, a, s, p);

            if (primero == null)
            {
                primero = nuevo;
            }
            else
            {
                Nodo actual = primero;
                while (actual.siguiente != null)
                {
                    actual = actual.siguiente;
                }
                actual.siguiente = nuevo;
            }
        }

        // MOSTRAR EN CONSOLA
        public void Mostrar()
        {
            Nodo actual = primero;

            if (actual == null)
            {
                Console.WriteLine("Lista vacía");
                return;
            }

            while (actual != null)
            {
                Console.WriteLine($"Nombre: {actual.nombre}");
                Console.WriteLine($"Género: {actual.genero}");
                Console.WriteLine($"Año: {actual.año}");
                Console.WriteLine($"Stock: {actual.stock}");
                Console.WriteLine($"Precio: {actual.precio}");
                Console.WriteLine("-------------------");

                actual = actual.siguiente;
            }
        }

        // MOSTRAR EN LISTBOX
        public void MostrarEnListBox(ListBox lista)
        {
            lista.Items.Clear();
            Nodo actual = primero;

            while (actual != null)
            {
                lista.Items.Add(
                    actual.nombre + " | " +
                    actual.genero + " | " +
                    actual.año + " | Stock: " +
                    actual.stock + " | S/ " +
                    actual.precio
                );

                actual = actual.siguiente;
            }
        }

        // ELIMINAR POR NOMBRE
        public void Eliminar(string nombre)
        {
            Nodo actual = primero;
            Nodo anterior = null;

            while (actual != null)
            {
                if (actual.nombre.Equals(nombre, StringComparison.OrdinalIgnoreCase))
                {
                    if (anterior == null)
                    {
                        primero = actual.siguiente;
                    }
                    else
                    {
                        anterior.siguiente = actual.siguiente;
                    }
                    return;
                }

                anterior = actual;
                actual = actual.siguiente;
            }
        }

        // BUSCAR POR NOMBRE
        public Nodo Buscar(string nombre)
        {
            Nodo actual = primero;

            while (actual != null)
            {
                if (actual.nombre.Equals(nombre, StringComparison.OrdinalIgnoreCase))
                {
                    return actual;
                }
                actual = actual.siguiente;
            }

            return null;
        }
    }
}
