﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace grupo5t1
{
    public partial class Form1 : Form
    {
        ListaVideojuegos lista = new ListaVideojuegos();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                lista.Agregar(
                    txtNombre.Text,
                    txtGenero.Text,
                    (int)numAnio.Value,
                    (int)numStock.Value,
                    double.Parse(txtPrecio.Text)
                );

                lista.MostrarEnListBox(listBoxJuegos);
                Limpiar();
            }
            catch
            {
                MessageBox.Show("Error al ingresar datos.");
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            lista.Eliminar(txtNombre.Text);
            lista.MostrarEnListBox(listBoxJuegos);
            Limpiar();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            lista.MostrarEnListBox(listBoxJuegos);
        }

        private void Limpiar()
        {
            txtNombre.Clear();
            txtGenero.Clear();
            txtPrecio.Clear();
            numAnio.Value = 2000;
            numStock.Value = 0;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}

