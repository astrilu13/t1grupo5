﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace grupo5t1
{
    public class Nodo
    {
        public string nombre;
        public string genero;
        public int año;
        public int stock;
        public double precio;

        public Nodo siguiente;

        public Nodo(string n, string g, int a, int s, double p)
        {
            nombre = n;
            genero = g;
            año = a;
            stock = s;
            precio = p;
            siguiente = null;
        }


    }
}
